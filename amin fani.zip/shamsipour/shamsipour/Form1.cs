﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace shamsipour
{
    public partial class Form1 : Form
    {
        SqlConnection sn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename='C:\Users\kiya\Desktop\my projects\windows projects\projects\shamsipour\shamsipour\Database1.mdf';Integrated Security=True");
        SqlDataAdapter ad;
        DataTable tb;

        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Hide();
            toolStripComboBox1.SelectedIndex = 0;
            toolStripComboBox2.SelectedIndex = 0;
        }
        private void toolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            TextBox[] txt1 = { textBox1, textBox2, textBox3, textBox4, textBox5, textBox6, textBox7 };
            switch (toolStripComboBox1.SelectedIndex)
            {
                case 0:
                    {
                        sn.Open();
                        panel1.Show();
                        ad = new SqlDataAdapter("select * from person", sn);
                        tb = new DataTable();
                        ad.Fill(tb);
                        dataGridView1.DataSource = tb;
                        for(int i = 0; i <7; i++)
                        {
                            if (i < tb.Columns.Count)
                            {
                                txt1[i].Text = tb.Columns[i].Caption;
                                txt1[i].Show();
                            }
                            else
                                txt1[i].Hide();
                        }
                        ad.Update((DataTable)(dataGridView1.DataSource));
                        sn.Close();
                        break;
                    }
                case 1:
                    {
                        sn.Open();
                        ad = new SqlDataAdapter("select * from teacher", sn);
                        tb = new DataTable();
                        ad.Fill(tb);
                        dataGridView1.DataSource = tb;
                        for (int i = 0; i < 7; i++)
                        {
                            if (i < tb.Columns.Count)
                            {
                                txt1[i].Text = tb.Columns[i].Caption;
                                txt1[i].Show();
                            }
                            else
                                txt1[i].Hide();
                        }
                        ad.Update((DataTable)(dataGridView1.DataSource));
                        sn.Close();
                        break;
                    }
                case 2:
                    {

                        sn.Open();
                        ad = new SqlDataAdapter("select * from student", sn);
                        tb = new DataTable();
                        ad.Fill(tb);
                        dataGridView1.DataSource = tb;
                        for (int i = 0; i < 7; i++)
                        {
                            if (i < tb.Columns.Count)
                            {
                                txt1[i].Text = tb.Columns[i].Caption;
                                txt1[i].Show();
                            }
                            else
                                txt1[i].Hide();
                        }
                        ad.Update((DataTable)(dataGridView1.DataSource));
                        sn.Close();
                        break;
                    }
                case 3:
                    {
                        sn.Open();
                        ad = new SqlDataAdapter("select * from student", sn);
                        tb = new DataTable();
                        ad.Fill(tb);
                        dataGridView1.DataSource = tb;
                        for (int i = 0; i < 7; i++)
                        {
                            if (i < tb.Columns.Count)
                            {
                                txt1[i].Text = tb.Columns[i].Caption;
                                txt1[i].Show();
                            }
                               
                            else
                                txt1[i].Hide();
                        }
                        ad.Update((DataTable)(dataGridView1.DataSource));
                        sn.Close();
                        break;
                    }
                case 4:
                    {
                        sn.Open();
                        ad = new SqlDataAdapter("select Id,payment from student", sn);
                        tb = new DataTable();
                        ad.Fill(tb);
                        dataGridView1.DataSource = tb;
                        for (int i = 0; i < 7; i++)
                        {
                            if (i < tb.Columns.Count)
                            {
                                txt1[i].Text = tb.Columns[i].Caption;
                                txt1[i].Show();
                            }
                            else
                                txt1[i].Hide();
                        }
                        ad.Update((DataTable)(dataGridView1.DataSource));
                        sn.Close();
                        break;
                    }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            TextBox[] txt1 = { textBox1, textBox2, textBox3, textBox4, textBox5, textBox6, textBox7 };
            string[] s = { "person", "teacher", "student", "student", "student" };
            try { 
            switch (toolStripComboBox1.SelectedIndex)
            {
                case 0:
                    {

                       switch(toolStripComboBox2.SelectedIndex)
                            {
                                case 0:
                                    { 
                        panel1.Show();
                        SqlCommand sc= new SqlCommand("INSERT INTO person (Id,name,lname,state) VALUES('"+txt1[0].Text+"','" + txt1[1].Text + "','" + txt1[2].Text + "','" + txt1[3].Text +  "')", sn);
                             sn.Open();
                            sc.ExecuteNonQuery();
                            sn.Close();
                            toolStripComboBox1.SelectedIndex = 0;

                                     break;
                                    }
                                case 1:
                                    {
                                        panel1.Show();
                                        SqlCommand sc = new SqlCommand("delete from person where Id= '" + txt1[0].Text + "'", sn);
                                        sn.Open();
                                        sc.ExecuteNonQuery();
                                        sn.Close();
                                        toolStripComboBox1.SelectedIndex = 0;

                                        break;
                                    }
                                case 2:
                                    {
                                        panel1.Show();
                                        SqlCommand sc = new SqlCommand("update person set Id='" + txt1[0].Text + "',name='" + txt1[1].Text + "',lname='" + txt1[2].Text + "',state='" + txt1[3].Text + "' where Id='"+ txt1[0].Text + "'", sn);
                                        sn.Open();
                                        sc.ExecuteNonQuery();
                                        sn.Close();
                                        toolStripComboBox1.SelectedIndex = 0;

                                        break;
                                    }
                            }
                            break;
                    }

                case 1:
                    {
                      
                     
                            switch (toolStripComboBox2.SelectedIndex)
                            {
                                case 0:
                                    {
                                        SqlCommand sc = new SqlCommand("insert into teacher (Id,name,lname,cource,fid) values('" + txt1[0].Text + "','" + txt1[1].Text + "','" + txt1[2].Text + "','" + txt1[3].Text + "','" + txt1[4].Text + "')", sn);
                                        sn.Open();
                                        sc.ExecuteNonQuery();
                                        sn.Close();
                                        toolStripComboBox1.SelectedIndex = 1;

                                        break;
                                    }
                                case 1:
                                    {
                                        panel1.Show();
                                        SqlCommand sc = new SqlCommand("delete from teacher where Id= '" + txt1[0].Text + "'", sn);
                                        sn.Open();
                                        sc.ExecuteNonQuery();
                                        sn.Close();
                                        toolStripComboBox1.SelectedIndex = 1;

                                        break;
                                    }
                                case 2:
                                    {
                                        panel1.Show();
                                        SqlCommand sc = new SqlCommand("update teacher set Id='" + txt1[0].Text + "',name='" + txt1[1].Text + "',lname='" + txt1[2].Text + "',cource='" + txt1[3].Text + "',fid='" + txt1[4].Text + "' where Id='" + txt1[0].Text + "'", sn);
                                        sn.Open();
                                        sc.ExecuteNonQuery();
                                        sn.Close();
                                        toolStripComboBox1.SelectedIndex = 1;

                                        break;
                                    }
                            }
                            break;
                        }
                case 2:
                    {

                            
                            switch (toolStripComboBox2.SelectedIndex)
                            {
                                case 0:
                                    {
                                        SqlCommand sc = new SqlCommand("insert into student (Id,name,lname,fid,cource,payment) values('" + txt1[0].Text + "','" + txt1[1].Text + "','" + txt1[2].Text + "','" + txt1[3].Text + "','" + txt1[4].Text + "','" + txt1[5].Text + "')", sn);
                                        sn.Open();
                                        sc.ExecuteNonQuery();
                                        sn.Close();
                                        toolStripComboBox1.SelectedIndex = 2;
                                        break;
                                    }
                                case 1:
                                    {
                                        panel1.Show();
                                        SqlCommand sc = new SqlCommand("delete from student where Id= '" + txt1[0].Text + "'", sn);
                                        sn.Open();
                                        sc.ExecuteNonQuery();
                                        sn.Close();
                                        toolStripComboBox1.SelectedIndex = 2;

                                        break;
                                    }
                                case 2:
                                    {
                                        panel1.Show();
                                        SqlCommand sc = new SqlCommand("update student set Id='" + txt1[0].Text + "',name='" + txt1[1].Text + "',lname='" + txt1[2].Text + "',fid='" + txt1[3].Text + "',cource='" + txt1[4].Text + "',payment='" + txt1[5].Text + "' where Id='" + txt1[0].Text + "'", sn);
                                        sn.Open();
                                        sc.ExecuteNonQuery();
                                        sn.Close();
                                        toolStripComboBox1.SelectedIndex = 2;

                                        break;
                                    }
                            }
                            break;
                        }
                case 3:
                    {
                        
                            switch (toolStripComboBox2.SelectedIndex)
                            {
                                case 0:
                                    {
                                        SqlCommand sc = new SqlCommand("insert into student (Id,name,lname,fid,cource,payment) values('" + txt1[0].Text + "','" + txt1[1].Text + "','" + txt1[2].Text + "','" + txt1[3].Text + "','" + txt1[4].Text + "','" + txt1[5].Text + "')", sn);
                                        sn.Open();
                                        sc.ExecuteNonQuery();
                                        sn.Close();
                                        toolStripComboBox1.SelectedIndex = 3;

                                        break;
                                    }
                                case 1:
                                    {
                                        panel1.Show();
                                        SqlCommand sc = new SqlCommand("delete from student where Id= '" + txt1[0].Text + "'", sn);
                                        sn.Open();
                                        sc.ExecuteNonQuery();
                                        sn.Close();
                                        toolStripComboBox1.SelectedIndex = 3;

                                        break;
                                    }
                                case 2:
                                    {
                                        panel1.Show();
                                        SqlCommand sc = new SqlCommand("update student set Id='" + txt1[0].Text + "',name='" + txt1[1].Text + "',lname='" + txt1[2].Text + "',fid='" + txt1[3].Text + "',cource='" + txt1[4].Text + "',payment='" + txt1[5].Text + "' where Id='" + txt1[0].Text + "'", sn);
                                        sn.Open();
                                        sc.ExecuteNonQuery();
                                        sn.Close();
                                        toolStripComboBox1.SelectedIndex = 3;

                                        break;
                                    }
                            }
                            break;
                        }
                case 4:
                    {
                        
                            switch (toolStripComboBox2.SelectedIndex)
                            {
                                case 0:
                                    {
                                        sn.Open();
                                        new SqlCommand("insert into student (Id,payment) values('" + txt1[0].Text + "','" + txt1[1].Text + "')", sn).ExecuteNonQuery();
                                        sn.Close();
                                        toolStripComboBox1.SelectedIndex = 4;

                                        break;
                                    }
                                case 1:
                                    {
                                        panel1.Show();
                                        SqlCommand sc = new SqlCommand("delete from student where Id= '" + txt1[0].Text + "'", sn);
                                        sn.Open();
                                        sc.ExecuteNonQuery();
                                        sn.Close();
                                        toolStripComboBox1.SelectedIndex = 4;

                                        break;
                                    }
                                case 2:
                                    {
                                        panel1.Show();
                                        SqlCommand sc = new SqlCommand("update student set Id='" + txt1[0].Text + "',payment='" + txt1[5].Text + "' where Id='" + txt1[0].Text + "'", sn);
                                        sn.Open();
                                        sc.ExecuteNonQuery();
                                        sn.Close();
                                        toolStripComboBox1.SelectedIndex = 4;

                                        break;
                                    }
                            }
                            break;
                        }
                   
            }

                sn.Open();
                ad = new SqlDataAdapter("select * from "+s[toolStripComboBox1.SelectedIndex], sn);
                tb = new DataTable();
                ad.Fill(tb);
                dataGridView1.DataSource = tb;
                for (int i = 0; i < 7; i++)
                {
                    if (i < tb.Columns.Count)
                    {
                        txt1[i].Text = tb.Columns[i].Caption;
                        txt1[i].Show();
                    }
                    else
                        txt1[i].Hide();
                }
                ad.Update((DataTable)(dataGridView1.DataSource));
                sn.Close();
                MessageBox.Show("done");
            }
            catch (Exception ex)
            {
                MessageBox.Show("not done" + Environment.NewLine + ex.Message);
            }
        }
        
        private void toolStripComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int t; TextBox[] txt1 = { textBox1, textBox2, textBox3, textBox4, textBox5, textBox6, textBox7 };
            switch (toolStripComboBox2.SelectedIndex)
            {
                case 0:
                    {

                        
                        t=toolStripComboBox1.SelectedIndex;
                        toolStripComboBox1.SelectedIndex = 0;
                        toolStripComboBox1.SelectedIndex = t;

                        button1.BackColor = Color.Lime;
                        button1.Text = "ثبت";
                        panel1.BackColor = Color.Green;

                        panel1.Show();
                        break;
                    }
                case 1:
                    {
                        t = toolStripComboBox1.SelectedIndex;
                        toolStripComboBox1.SelectedIndex = 0;
                        toolStripComboBox1.SelectedIndex = t;

                        button1.BackColor = Color.Red;
                        button1.Text = "حذف";
                        panel1.BackColor = Color.DarkRed;

                      
                        for (int i = 0; i < 7; i++)
                        {
                            if (i == 0)
                            {
                                txt1[i].Text = "Id";
                                txt1[i].Show();
                            }
                            else
                                txt1[i].Hide();
                        }
                      
                        panel1.Show();

                        break;
                    }
                case 2:
                    {
                        t = toolStripComboBox1.SelectedIndex;
                        toolStripComboBox1.SelectedIndex = 0;
                        toolStripComboBox1.SelectedIndex = t;

                        button1.BackColor = Color.LightBlue;
                        button1.Text = "بروزرسانی";
                        panel1.BackColor = Color.Blue;

                        panel1.Show();

                        break;
                    }
                case 3:
                    {
                        t = toolStripComboBox1.SelectedIndex;
                        toolStripComboBox1.SelectedIndex = 0;
                        toolStripComboBox1.SelectedIndex = t;
                        panel1.Hide();
                        break;
                    }
            }
        }
    }
}
